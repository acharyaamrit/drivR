//: Playground - noun: a place where people can play

import UIKit

let summationOperation = NSBlockOperation(block: {
    let result = 2 + 3
})

summationOperation.start()




